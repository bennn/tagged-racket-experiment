for BM in acquire-worst determinance dungeon-typed dungeon-worst forth-bad fsm fsmoo gregor-worst kcfa-worst lnm-worst mbta-worst morsecode-worst quadBG-worst quadMB-worst snake-worst synth take5-worst tetris-worst trie-vector zombie-worst zordoz-worst; do
  cd ${BM};
  raco make main.rkt;
  cd ..;
done
