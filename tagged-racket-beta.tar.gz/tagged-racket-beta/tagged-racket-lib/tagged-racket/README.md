tagged-diverge
===

TODO
- [ ] provides
  - [X] via macros
  - [X] via chaperones
  - [ ] compare
- [ ] how to map? other destructors

- [ ] make sure define-predicate makes a deep contract, use quadMB to test

- [ ] make contracts more efficient
  - [ ] shorter runtime code for vector/c etc.
  - [ ] make sure contract-expr is never an expression
  - [ ] lift contract defs to submodule, use a cache

- [ ] use `contract-first-order`
  - is this always what I want? (only checks class/obj names)
- [ ] are object,class,unit first-order checks "correct"?
  - revert all changes, just apply first-order at last second
- [ ] why use static-contracts at all?
  - [ ] optimizations (can't do this with contracts?)

Naming
---

use a keyword? `#lang typed/racket #:preserve (or/c 'types 'tags 'nothing)`

`(provide (type-out ....) (tag-out ....))`
 its weird because needs to know full type, but not trust anything but tag

