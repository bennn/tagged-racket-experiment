tagged-diverge
===

TODO
- [X] provides
  - [X] via macros
  - [X] via chaperones
  - [X] compare NO BIG DIFFERENCE
- [X] re-implement via static-contracts
  - [X] hack
  - [X] add logging
  - [X] test

- [X] debug zombie, why so slowwww?
  - 6 seconds on 0001 0011 1001 1011
  - was rec-contracts getting compiled to chaperones

;; - [ ] THIS IS HOPELESS
;;   - [ ] protect typed, first-class functions
;;         (filter (λ ....) untyped-data)
;;   - [ ] do not check codomain of typed functions
;;         ... check the type table?
;;   - IMPOSSIBLE TO DO THESE THINGS WITH REWRITING,
;;     would need to protect ALL DOMAINS
;;     and check all codomains unless sure --- which is overapprox
;; - [ ] so lets just try chaperones, that should be safe
;;   - no more defender, no more rewriting
;; 
;; ... calm down, there's clearly a problem but need to think through solutions
;;     and possible next steps.
;;     1. all untyped, higher-order has "Any" in negative dom positions (dom^2)
;;     2. function boundaries
;;     3. all untyped, higher-order has contract
;;        (!!! but not sure what contract to make until instantiated)
;;        - so far like this best, lots of require/typed using simpler contracts

- - -

Well okay, we had unsound version. Fun. Sad. Fix it.

1. Make simplest sound version,
   - always check domain
   - always check codomain
   (already handled range and non-higher-order domains)
2. try easy optimizations
   - trusted codomains
   - if (f x) in typed code, change to "unsafe f" that skips the dom check
3. 


- [ ] LNM tagged version (plot module is trouble)
- [ ] determinance GTP

- [ ] make sure define-predicate makes a deep contract, use quadMB to test

- [ ] make contracts more efficient
  - [ ] shorter runtime code for vector/c etc.
  - [ ] make sure contract-expr is never an expression
  - [ ] lift contract defs to submodule, use a cache

- [ ] use `contract-first-order`
  - is this always what I want? (only checks class/obj names)
- [ ] are object,class,unit first-order checks "correct"?
  - revert all changes, just apply first-order at last second
- [ ] why use static-contracts at all?
  - [ ] optimizations (can't do this with contracts?)

- [ ] NEED to re-run Typed Racket, because these programs are different from GTP
      more require/typed

- [ ] fix `values`, see `tagged-racket-test/bg/error/values.rkt`
      issue is, (#%app f _) dones't have a type if `f` returns multiple values
      ... not sure what TR does about this


Functional vs. OO
---

2017-09-15 : don't worry about OO for now.

| Benchmark    | O |
|--------------+---|
| acquire      | X |
| determinance |   |
| dungeon      | X |
| forth        | X |
| fsm          |   |
| fsmoo        | X |
| gregor       |   |
| kcfa         |   |
| lnm          |   |
| mbta         | X |
| morsecode    |   |
| quadBG       | X |
| quadMB       | X |
| snake        |   |
| suffixtree   |   |
| synth        |   |
| take5        | X |
| tetris       |   |
| trie-vector  |   |
| zombie       |   |
| zordoz       |   |


Naming
---

use a keyword? `#lang typed/racket #:preserve (or/c 'types 'tags 'nothing)`

`(provide (type-out ....) (tag-out ....))`
 its weird because needs to know full type, but not trust anything but tag

